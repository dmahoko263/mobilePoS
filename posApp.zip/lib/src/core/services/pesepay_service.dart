import 'package:pesepay/pesepay.dart';

final pesepay = Pesepay(
  integrationKey: 'cda06c6f-6446-441c-bb61-913d8b1071da',
  encryptionKey: 'YOUR_ENCRYPTION_KEY',
  resultUrl: 'https://yourdomain.com/result',
  returnUrl: 'https://yourdomain.com/return',
);
